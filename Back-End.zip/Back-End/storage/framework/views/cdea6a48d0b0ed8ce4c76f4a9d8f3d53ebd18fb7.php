<nav class="navbar navbar-dark fixed-top bg-dark flex-md-nowrap p-0 shadow">
    <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="events/index.html">Nền tảng sự kiện</a>
    <span class="navbar-organizer w-100"><?php echo e(session()->get('user')['name']); ?></span>
    <ul class="navbar-nav px-3">
        <li class="nav-item text-nowrap">
            <a class="nav-link" id="logout" href="<?php echo e(route('logout')); ?>">Đăng xuất</a>
        </li>
    </ul>
</nav><?php /**PATH D:\Learn_FPT\worldSkill\Back-End\resources\views/layout/_header.blade.php ENDPATH**/ ?>