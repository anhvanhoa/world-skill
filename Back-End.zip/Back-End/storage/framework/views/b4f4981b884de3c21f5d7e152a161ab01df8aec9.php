<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Event Backend</title>

    <base href="<?php echo e(asset('')); ?>">
    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <!-- Custom styles -->
    <link href="assets/css/custom.css" rel="stylesheet">
    <script src="assets/js/main.js" defer></script>
</head>

<body>
    <!-- header web -->
    <?php echo $__env->make('layout/_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /header web -->
    <div class="container-fluid">
        <div class="row">
            <!-- sidebar web -->
            <?php echo $__env->make('layout/_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- /sidebar web -->
            <!-- main web -->
            <?php echo $__env->yieldContent('content'); ?>
            <!-- /main web -->
        </div>
    </div>

</body>

</html><?php /**PATH D:\Learn_FPT\worldSkill\Back-End\resources\views/layout/_home.blade.php ENDPATH**/ ?>