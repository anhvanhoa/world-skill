<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Hội thảo kỹ năng nghề TP Hà Nội 2023</title>

    <base href="<?php echo e(asset('')); ?>">
    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <!-- Custom styles -->
    <link href="assets/css/custom.css" rel="stylesheet">
</head>

<body>

    <div class="container-fluid">
        <div class="row">
            <main class="col-md-6 mx-sm-auto px-4">
                <div class="pt-3 pb-2 mb-3 border-bottom text-center">
                    <h1 class="h2">Hội thảo kỹ năng nghề TP Hà Nội 2023</h1>
                </div>
                <?php if(Session::has('error')): ?>
                <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
                <form class="form-signin" action="<?php echo e(route('login')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <h1 class="h3 mb-3 font-weight-normal">Đăng nhập</h1>
                    <label for="inputEmail" class="sr-only">Email</label>
                    <input type="email" id="inputEmail" name="email" class="form-control" placeholder="Email" autofocus>
                    <label for="inputPassword" class="sr-only">Mật khẩu</label>
                    <input type="password" id="inputPassword" name="password" class="form-control" placeholder="Mật khẩu">
                    <button class="btn btn-lg btn-primary btn-block" id="login" type="submit">Đăng nhập</button>
                </form>
            </main>
        </div>
    </div>
</body>

</html><?php /**PATH C:\Users\Anh Van Hoa\Downloads\Cong nghe web\Cong nghe web\TaiNguyen\php_framework\project\resources\views/index.blade.php ENDPATH**/ ?>