@extends('layout/_home')

@section('content')
<main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
    <div class="border-bottom mb-3 pt-3 pb-2">
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center">
            <h1 class="h2">{{ $event->name }}</h1>
        </div>
        <span class="h6">{{ $event->date }}</span>
    </div>

    <div class="mb-3 pt-3 pb-2">
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center">
            <h2 class="h4">Tạo vé mới</h2>
        </div>
    </div>

    <form class="needs-validation" novalidate action="{{ route('create-ticket', $event->id) }}" method="post">
        @csrf
        <div class="row">
            <div class="col-12 col-lg-4 mb-3">
                <label for="inputName">Tên</label>
                <!-- adding the class is-invalid to the input, shows the invalid feedback below -->
                <input type="text" class="form-control @error('name') is-invalid @enderror" id="inputName" name="name" placeholder="" value="">
                @error('name')
                <div class="invalid-feedback">
                    {{$message}}
                </div>
                @enderror
            </div>
        </div>

        <div class="row">
            <div class="col-12 col-lg-4 mb-3">
                <label for="inputCost">Giá</label>
                <input type="number" class="form-control @error('cost') is-invalid @enderror" id="inputCost" name="cost" placeholder="" value="">
                @error('cost')
                <div class="invalid-feedback">
                    {{$message}}
                </div>
                @enderror
            </div>
        </div>

        <div class="row">
            <div class="col-12 col-lg-4 mb-3">
                <label for="selectSpecialValidity">Hiệu lực đặc biệt</label>
                <select class="form-control" id="selectSpecialValidity" name="special_validity">
                    <option value="" selected>Không</option>
                    <option value="amount">Số lượng giới hạn</option>
                    <option value="date">Có thể mua đến ngày</option>
                </select>
            </div>
        </div>

        <!-- <div class="row">
            <div class="col-12 col-lg-4 mb-3">
                <label for="inputAmount">Số lượng vé tối đa được bán</label>
                <input type="number" class="form-control" id="inputAmount" name="valid_until" placeholder="" value="0">
            </div>
        </div> -->

        <div class="row">
            <div class="col-12 col-lg-4 mb-3 d-none ">
                <label for="inputValidTill" class="valid_until">Vé có thể được bán đến</label>
                <input type="text" class="form-control @error('valid_until') is-invalid @enderror" id="inputValidTill" name="valid_until" placeholder="yyyy-mm-dd HH:MM" value="0">
                @error('valid_until')
                <div class="invalid-feedback">
                    {{$message}}
                </div>
                @enderror
            </div>
        </div>
        <input type="hidden" name="slug" value="{{ $event->slug }}">
        <hr class="mb-4">
        <button class="btn btn-primary" type="submit">Lưu vé</button>
        <a href="events/detail.html" class="btn btn-link">Bỏ qua</a>
    </form>
</main>

@stop