<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Event Backend</title>

    <base href="{{ asset('') }}">
    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <!-- Custom styles -->
    <link href="assets/css/custom.css" rel="stylesheet">
    <script src="assets/js/main.js" defer></script>
</head>

<body>
    <!-- header web -->
    @include('layout/_header')
    <!-- /header web -->
    <div class="container-fluid">
        <div class="row">
            <!-- sidebar web -->
            @include('layout/_sidebar')
            <!-- /sidebar web -->
            <!-- main web -->
            @yield('content')
            <!-- /main web -->
        </div>
    </div>

</body>

</html>